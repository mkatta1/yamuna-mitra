
## Description
Write some spark code which returns the number of trips for each customerid.
A trip is a sequence of travel transactions with no more than 7 days in between
each transaction.

##### Input: (customerid,fname,lname,gender,date)
##### Output: (customerid, numTrips)
