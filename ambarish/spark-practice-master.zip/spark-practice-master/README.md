# Spark Practice

### Description
Practice problems for getting started with Apache Spark



1. Count of Trips :
https://github.com/ambarishHazarnis/spark-practice/blob/master/src/main/scala/probelms/trips

2. Traffic Source Distribution : https://github.com/ambarishHazarnis/spark-practice/tree/master/src/main/scala/probelms/trafficSource

3. Customer Insights : https://github.com/ambarishHazarnis/spark-practice/tree/master/src/main/scala/probelms/customerInsights

4. Handle Skew

5. PageRank
